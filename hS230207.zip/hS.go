// https://medium.com/@mlowicki/http-s-proxy-in-golang-in-less-than-100-lines-of-code-6a51c2f2c38c
package main

import (
	"encoding/base64"
	"flag"
	"io"
	"log"
	"net"
	"bytes"
	"github.com/valyala/fasthttp"
)

var secretlink []byte = []byte("zhima.kaimen")
var userPass []byte = []byte("Basic " + base64.URLEncoding.EncodeToString([]byte("neo:5b73add1")))

func requestHandler(ctx *fasthttp.RequestCtx) {
	if bytes.Equal(ctx.Request.Header.Peek("Proxy-Authorization"),userPass) {
		if bytes.Equal(ctx.Method(), []byte("CONNECT")) {
			if destConn, err := fasthttp.DialDualStack(string(ctx.Request.Host())); err == nil {
				buf := make([]byte, 256*1024)
				hijackHandler := func(clientConn net.Conn) {
					defer destConn.Close()
					defer clientConn.Close()
					errc := make(chan error)//could be 0 or 1					
					trf := func(destination io.Writer, source io.Reader) {
						_, err := io.CopyBuffer(destination, source, buf)
						errc <- err
					}
					go trf(destConn, clientConn)
					go trf(clientConn, destConn)
					<-errc
				}
				ctx.Hijack(hijackHandler)
			}			
		} else {
			fasthttp.DoRedirects(&ctx.Request, &ctx.Response, 10)
		}		
	}else{
		if bytes.Equal(ctx.Request.Host(), secretlink) {
			ctx.Response.Header.Set("Proxy-Authenticate", "Basic realm=\"Caddy Secure Web Proxy\"")
			ctx.Response.Header.SetStatusCode(407)//http.StatusProxyAuthRequired
		}		
	}	
}

var (
	pemPath    = flag.String("pem", "server.pem", "path to pem file")
	keyPath    = flag.String("key", "server.key", "path to key file")
	proto      = flag.String("proto", "https", "Proxy protocol (http or https)")
	userPassIn = flag.String("userpass", "null", "username:password (len>5)")
	ipaddr     = flag.String("ipaddr", "", "Proxy ipaddr(default:)")
	port       = flag.String("port", "8888", "Proxy port(default: 8888)")
)

func main() {
	flag.Parse()
	if len(*userPassIn) > 5 {
		userPass =[]byte( "Basic " + base64.URLEncoding.EncodeToString([]byte(*userPassIn)))
	}
	if *proto == "https" {
		log.Fatal(fasthttp.ListenAndServeTLS(*ipaddr+":"+*port, *pemPath, *keyPath, requestHandler))		
	} else if *proto == "http" {
		log.Fatal(fasthttp.ListenAndServe(*ipaddr+":"+*port, requestHandler))
	} else {
		log.Fatal("Protocol must be either http or https")
	}
}
