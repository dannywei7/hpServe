// https://medium.com/@mlowicki/http-s-proxy-in-golang-in-less-than-100-lines-of-code-6a51c2f2c38c
package main
import (
    "crypto/tls"
    "flag"
    "io"
    "log"
    "net"
    "net/http"
	"time"
	"strings"
	"encoding/base64"
)
const secretlink = "zhima.kaimen"
var userPass string
//const unauth = http.StatusProxyAuthRequired
const unauth = http.StatusUnauthorized

func stripPort(address string) string {
	// The address might be a IPv6 address that contains a colon, but not followed by a port.
	portIdx := strings.LastIndex(address, ":")
	ipv6Idx := strings.LastIndex(address, "]")
	if portIdx > ipv6Idx {
		address = address[:portIdx]
	}
	return address
}

func selfAuth(w http.ResponseWriter, r *http.Request, auth string ) bool {
	if !strings.HasPrefix(auth, "Basic ") { 
		if stripPort(r.Host) == secretlink {
			w.Header().Set("Proxy-Authenticate", "Basic realm=\"Caddy Secure Web Proxy\"")
			w.WriteHeader(http.StatusProxyAuthRequired)  
		}	  
	  	http.Error(w, http.StatusText(unauth), unauth)
	  	return false
	}
	up, err := base64.StdEncoding.DecodeString(auth[6:])
	if err != nil {
		http.Error(w, http.StatusText(unauth), unauth)
		return false
	}
	if string(up) != userPass {
		http.Error(w, http.StatusText(unauth), unauth)
		return false
	}
	return true
}

func handleTunneling(w http.ResponseWriter, r *http.Request) {
	auth := r.Header.Get("Proxy-Authorization")
	if auth == "" {
		http.Error(w, http.StatusText(unauth), unauth)
		return
	}
	if !selfAuth(w, r, auth){
		return
	}
    destConn, err := net.DialTimeout("tcp", r.Host, 10*time.Second)
    if err != nil {
        http.Error(w, err.Error(), http.StatusServiceUnavailable)
        return
    }
    w.WriteHeader(http.StatusOK)
    hijacker, ok := w.(http.Hijacker)
    if !ok {
        http.Error(w, "HCijacking not supported", http.StatusInternalServerError)
        return
    }
    clientConn, _, err := hijacker.Hijack()
    if err != nil {
        http.Error(w, err.Error(), http.StatusServiceUnavailable)
    }
    go transfer(destConn, clientConn)
    go transfer(clientConn, destConn)
}

func transfer(destination io.WriteCloser, source io.ReadCloser) {
    defer destination.Close()
    defer source.Close()
    io.Copy(destination, source)
}

func handleHTTP(w http.ResponseWriter, req *http.Request) {
   	auth := req.Header.Get("Proxy-Authorization")
	if !selfAuth(w, req, auth){
		return
	}	
    resp, err := http.DefaultTransport.RoundTrip(req)
    if err != nil {
        http.Error(w, err.Error(), http.StatusServiceUnavailable)
        return
    }
	defer resp.Body.Close()
    copyHeader(w.Header(), resp.Header)
    w.WriteHeader(resp.StatusCode)
    io.Copy(w, resp.Body)
}

func copyHeader(dst, src http.Header) {
    for k, vv := range src {
        for _, v := range vv {
            dst.Add(k, v)
        }
    }
}

func main() {
    var pemPath string
    flag.StringVar(&pemPath, "pem", "server.pem", "path to pem file")
    var keyPath string
    flag.StringVar(&keyPath, "key", "server.key", "path to key file")
    var proto string
    flag.StringVar(&proto, "proto", "https", "Proxy protocol (http or https)")
    var userPassIn string
    flag.StringVar(&userPassIn, "userpass", "null", "username:password (len>5)")
    var ipaddr string
	flag.StringVar(&ipaddr, "ipaddr", "", "Proxy ipaddr(default:)")
	var port string
	flag.StringVar(&port, "port", "8888", "Proxy port(default: 8888)")
    flag.Parse()

    if len(userPassIn) >5{
        userPass = userPassIn
    }else{
        userPass = "neo:5b73add1"
    }
    if proto != "http" && proto != "https" {
        log.Fatal("Protocol must be either http or https")
    }
    server := &http.Server{
        Addr: ipaddr + ":" + port,
        Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
            if r.Method == http.MethodConnect {
                handleTunneling(w, r)
            } else {
                handleHTTP(w, r)
            }
        }),
        // Disable HTTP/2.
        TLSNextProto: make(map[string]func(*http.Server, *tls.Conn, http.Handler)),
    }
    if proto == "http" {
        log.Fatal(server.ListenAndServe())
    } else {
        log.Fatal(server.ListenAndServeTLS(pemPath, keyPath))
    }
}
