// https://medium.com/@mlowicki/http-s-proxy-in-golang-in-less-than-100-lines-of-code-6a51c2f2c38c
package main
import (
    "crypto/tls"
    "flag"
    "io"
    "log"
    "net"
    "net/http"
	"time"
	"encoding/base64"
)
const secretlink = "zhima.kaimen"
var userPass string
//const unauth = http.StatusProxyAuthRequired
const unauth = http.StatusUnauthorized

func selfAuth(w http.ResponseWriter, r *http.Request ) bool {
    auth := r.Header.Get("Proxy-Authorization")
	if (auth == "") || (auth[0:6] != "Basic ") {
		if r.Host == secretlink {
			w.Header().Set("Proxy-Authenticate", "Basic realm=\"Caddy Secure Web Proxy\"")
			w.WriteHeader(http.StatusProxyAuthRequired)  
		}	  
	  	http.Error(w, http.StatusText(unauth), unauth)
	  	return false
	}
	if auth[6:]!= userPass {
		http.Error(w, http.StatusText(unauth), unauth)
		return false
	}
	return true
}

func handleTunneling(w http.ResponseWriter, r *http.Request) {
    destConn, err := net.DialTimeout("tcp", r.Host, 10*time.Second)
    if err != nil {
        http.Error(w, err.Error(), http.StatusServiceUnavailable)
        return
    }
    w.WriteHeader(http.StatusOK)
    hijacker, ok := w.(http.Hijacker)
    if !ok {
        http.Error(w, "HCijacking not supported", http.StatusInternalServerError)
        return
    }
    clientConn, _, err := hijacker.Hijack()
    if err != nil {
        http.Error(w, err.Error(), http.StatusServiceUnavailable)
        return
    }
    go transfer(destConn, clientConn)
    go transfer(clientConn, destConn)
}

func transfer(destination io.WriteCloser, source io.ReadCloser) {
    defer destination.Close()
    defer source.Close()
    io.Copy(destination, source)
}

func handleHTTP(w http.ResponseWriter, req *http.Request) {
    resp, err := http.DefaultTransport.RoundTrip(req)
    if err != nil {
        http.Error(w, err.Error(), http.StatusServiceUnavailable)
        return
    }
	defer resp.Body.Close()
    copyHeader(w.Header(), resp.Header)
    w.WriteHeader(resp.StatusCode)
    io.Copy(w, resp.Body)
}

func copyHeader(dst, src http.Header) {
    for k, vv := range src {
        for _, v := range vv {
            dst.Add(k, v)
        }
    }
}

var(
    pemPath = flag.String("pem", "server.pem", "path to pem file")
    keyPath = flag.String("key", "server.key", "path to key file")
    proto = flag.String("proto", "https", "Proxy protocol (http or https)")
    userPassIn = flag.String("userpass", "null", "username:password (len>5)")
    ipaddr = flag.String("ipaddr", "", "Proxy ipaddr(default:)")
	port = flag.String("port", "8888", "Proxy port(default: 8888)")
)

func main() {    
    flag.Parse()
    if len(*userPassIn) >5{
		userPass = string(base64.URLEncoding.EncodeToString([]byte(*userPassIn)))
    }else{
		userPass = string(base64.URLEncoding.EncodeToString([]byte("neo:5b73add1")))
    }	
    if *proto != "http" && *proto != "https" {
        log.Fatal("Protocol must be either http or https")
    }
    server := &http.Server{
        Addr: *ipaddr + ":" + *port,
        Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {                        
            if selfAuth(w, r){     
                if r.Method == http.MethodConnect {
                    handleTunneling(w, r)
                } else {
                    handleHTTP(w, r)
                }
            }
        }),
        // Disable HTTP/2.
        TLSNextProto: make(map[string]func(*http.Server, *tls.Conn, http.Handler)),
    }
    if *proto == "http" {
        log.Fatal(server.ListenAndServe())
    } else {
        log.Fatal(server.ListenAndServeTLS(*pemPath, *keyPath))
    }
}