// https://medium.com/@mlowicki/http-s-proxy-in-golang-in-less-than-100-lines-of-code-6a51c2f2c38c
package main

import (
	"encoding/base64"
	"flag"
	"io"
	"log"
	"net"
	"net/http"
	"time"

	"github.com/valyala/fasthttp"
)

const secretlink = "zhima.kaimen"

var userPass string = "Basic " + base64.URLEncoding.EncodeToString([]byte("neo:5b73add1"))

//const unauth = http.StatusProxyAuthRequired
const unauth = http.StatusUnauthorized

func selfAuth(ctx *fasthttp.RequestCtx) bool {
	if string(ctx.Request.Header.Peek("Proxy-Authorization")) == userPass {
		return true
	}
	if string(ctx.Request.Host()) == secretlink {
		ctx.Response.Header.Set("Proxy-Authenticate", "Basic realm=\"Caddy Secure Web Proxy\"")
		ctx.Response.Header.SetStatusCode(http.StatusProxyAuthRequired)
	}
	return false
}

func handleTunneling(ctx *fasthttp.RequestCtx) {
	destConn, err := fasthttp.DialTimeout(string(ctx.Request.Host()), 10*time.Second)
	if err == nil {
		hijackHandler := func(clientConn net.Conn) {
			defer destConn.Close()
			defer clientConn.Close()
			errc := make(chan error, 2)
			trf := func(destination io.Writer, source io.Reader) {
				_, err := io.Copy(destination, source)
				errc <- err
			}
			go trf(destConn, clientConn)
			go trf(clientConn, destConn)
			<-errc
		}
		ctx.Hijack(hijackHandler)
	}
}

func handleHTTP(ctx *fasthttp.RequestCtx) {
	fasthttp.DoRedirects(&ctx.Request, &ctx.Response, 10)
}

func requestHandler(ctx *fasthttp.RequestCtx) {
	if selfAuth(ctx) {
		if string(ctx.Method()) == "CONNECT" {
			handleTunneling(ctx)
		} else {
			handleHTTP(ctx)
		}
	}
}

var (
	pemPath    = flag.String("pem", "server.pem", "path to pem file")
	keyPath    = flag.String("key", "server.key", "path to key file")
	proto      = flag.String("proto", "https", "Proxy protocol (http or https)")
	userPassIn = flag.String("userpass", "null", "username:password (len>5)")
	ipaddr     = flag.String("ipaddr", "", "Proxy ipaddr(default:)")
	port       = flag.String("port", "8888", "Proxy port(default: 8888)")
)

func main() {
	flag.Parse()
	if len(*userPassIn) > 5 {
		userPass = "Basic " + base64.URLEncoding.EncodeToString([]byte(*userPassIn))
	}
	if *proto == "http" {
		log.Fatal(fasthttp.ListenAndServe(*ipaddr+":"+*port, requestHandler))
	} else if *proto == "https" {
		log.Fatal(fasthttp.ListenAndServeTLS(*ipaddr+":"+*port, *pemPath, *keyPath, requestHandler))
	} else {
		log.Fatal("Protocol must be either http or https")
	}
}
